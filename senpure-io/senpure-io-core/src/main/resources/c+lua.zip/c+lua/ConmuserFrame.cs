﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dotNetty

{
    class ConsumerFrame
    {
        private Object message;

        public object Message { get => message; set => message = value; }
    }
}
