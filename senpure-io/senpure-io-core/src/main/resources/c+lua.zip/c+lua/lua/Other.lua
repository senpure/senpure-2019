

print("other lua.....")