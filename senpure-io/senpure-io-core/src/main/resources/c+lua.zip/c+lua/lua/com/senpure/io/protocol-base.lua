--[[
author    senpure
version   2019-12-23 15:12:23

message : Io.CSHeartMessage       65   心跳
message : Io.SCHeartMessage       66   心跳
message : Io.SCInnerErrorMessage  100  服务器内部错误提示
--]]

Io = Io or {}



--[[
    心跳
--]]
Io.CSHeartMessage = {
    --[Comment]
    --message_id
    messageId = 65;
    serializedSize = -1;
}

--Io.CSHeartMessage构造方法
function Io.CSHeartMessage:new()
    local csHeartMessage = setmetatable({}, {__index=self}) ;
    csHeartMessage.serializedSize = -1;
    return csHeartMessage;
end

--Io.CSHeartMessage写入字节缓存
function Io.CSHeartMessage:write(buf)
    self:getSerializedSize(buf);
end

--Io.CSHeartMessage读取字节缓存
function Io.CSHeartMessage:read(buf,endIndex)
    local switch = {
    }
    while(true) do
        local tag = buf:ReadTag(endIndex);
        if(tag == 0) then
            return;
        else
            local case = switch[tag];
            if(case) then
                case();
            else
                buf:Skip(tag);
            end
        end
    end
end

--Io.CSHeartMessage计算序列化大小
function Io.CSHeartMessage:getSerializedSize(buf)
    local size = self.serializedSize;
    if (size > -1) then
        return size;
    end
    size = 0;
    self.serializedSize = size ;
    return size ;
end

--Io.CSHeartMessage格式化字符串
function Io.CSHeartMessage:toString(_indent)
    _indent = _indent or ""
    local _str = ""
    _str = _str .. "CSHeartMessage[65]" .. "{"
    _str =_str .. "\n"
    _str = _str .. _indent .. "}"
    return _str
end


--[[
    心跳
--]]
Io.SCHeartMessage = {
    --[Comment]
    --message_id
    messageId = 66;
    serializedSize = -1;
}

--Io.SCHeartMessage构造方法
function Io.SCHeartMessage:new()
    local scHeartMessage = setmetatable({}, {__index=self}) ;
    scHeartMessage.serializedSize = -1;
    return scHeartMessage;
end

--Io.SCHeartMessage写入字节缓存
function Io.SCHeartMessage:write(buf)
    self:getSerializedSize(buf);
end

--Io.SCHeartMessage读取字节缓存
function Io.SCHeartMessage:read(buf,endIndex)
    local switch = {
    }
    while(true) do
        local tag = buf:ReadTag(endIndex);
        if(tag == 0) then
            return;
        else
            local case = switch[tag];
            if(case) then
                case();
            else
                buf:Skip(tag);
            end
        end
    end
end

--Io.SCHeartMessage计算序列化大小
function Io.SCHeartMessage:getSerializedSize(buf)
    local size = self.serializedSize;
    if (size > -1) then
        return size;
    end
    size = 0;
    self.serializedSize = size ;
    return size ;
end

--Io.SCHeartMessage格式化字符串
function Io.SCHeartMessage:toString(_indent)
    _indent = _indent or ""
    local _str = ""
    _str = _str .. "SCHeartMessage[66]" .. "{"
    _str =_str .. "\n"
    _str = _str .. _indent .. "}"
    return _str
end


--[[
    服务器内部错误提示
--]]
Io.SCInnerErrorMessage = {
    --[Comment]
    --message_id
    messageId = 100;
    --[Comment]
    --类型:String 错误类型
    type = "";
    --[Comment]
    --类型:String 提示内容
    message = "";
    --[Comment]
    --类型:int    消息id
    id = 0;
    --[Comment]
    --类型:String ask的value
    value = "";
    serializedSize = -1;
}

--Io.SCInnerErrorMessage构造方法
function Io.SCInnerErrorMessage:new()
    local scInnerErrorMessage = setmetatable({}, {__index=self}) ;
    --[Comment]
    --类型:String 错误类型
    scInnerErrorMessage.type = "";
    --[Comment]
    --类型:String 提示内容
    scInnerErrorMessage.message = "";
    --[Comment]
    --类型:int    消息id
    scInnerErrorMessage.id = 0;
    --[Comment]
    --类型:String ask的value
    scInnerErrorMessage.value = "";
    scInnerErrorMessage.serializedSize = -1;
    return scInnerErrorMessage;
end

--Io.SCInnerErrorMessage写入字节缓存
function Io.SCInnerErrorMessage:write(buf)
    self:getSerializedSize(buf);
    --错误类型
    if self.type then
        buf:WriteString(11, self.type);
    end
    --提示内容
    if self.message then
        buf:WriteString(19, self.message);
    end
    --消息id
    buf:WriteVar32(24, self.id);
    --ask的value
    if self.value then
        buf:WriteString(35, self.value);
    end
end

--Io.SCInnerErrorMessage读取字节缓存
function Io.SCInnerErrorMessage:read(buf,endIndex)
    local switch = {
        -- 错误类型
        -- 1 << 3 | 3
        [11] = function ()
        self.type = buf:ReadString();
    end ,
        -- 提示内容
        -- 2 << 3 | 3
        [19] = function ()
        self.message = buf:ReadString();
    end ,
        -- 消息id
        -- 3 << 3 | 0
        [24] = function ()
        self.id = buf:ReadVar32();
    end ,
        -- ask的value
        -- 4 << 3 | 3
        [35] = function ()
        self.value = buf:ReadString();
    end 
    }
    while(true) do
        local tag = buf:ReadTag(endIndex);
        if(tag == 0) then
            return;
        else
            local case = switch[tag];
            if(case) then
                case();
            else
                buf:Skip(tag);
            end
        end
    end
end

--Io.SCInnerErrorMessage计算序列化大小
function Io.SCInnerErrorMessage:getSerializedSize(buf)
    local size = self.serializedSize;
    if (size > -1) then
        return size;
    end
    size = 0;
    -- 错误类型
    if self.type then
        -- tag size 已经完成了计算 11
        size = size + buf:ComputeStringSize(1, self.type);
    end
    -- 提示内容
    if self.message then
        -- tag size 已经完成了计算 19
        size = size + buf:ComputeStringSize(1, self.message);
    end
    -- 消息id
    -- tag size 已经完成了计算 24
    size = size + buf:ComputeVar32Size(1, self.id);
    -- ask的value
    if self.value then
        -- tag size 已经完成了计算 35
        size = size + buf:ComputeStringSize(1, self.value);
    end
    self.serializedSize = size ;
    return size ;
end

--Io.SCInnerErrorMessage格式化字符串
function Io.SCInnerErrorMessage:toString(_indent)
    _indent = _indent or ""
    local _str = ""
    _str = _str .. "SCInnerErrorMessage[100]" .. "{"
    --错误类型
    _str = _str .. "\n"
    _str = _str .. _indent .. "type    = " .. self.type
    --提示内容
    _str = _str .. "\n"
    _str = _str .. _indent .. "message = " .. self.message
    --消息id
    _str = _str .. "\n"
    _str = _str .. _indent .. "id      = " .. self.id
    --ask的value
    _str = _str .. "\n"
    _str = _str .. _indent .. "value   = " .. self.value
    _str =_str .. "\n"
    _str = _str .. _indent .. "}"
    return _str
end

--get 错误类型
function Io.SCInnerErrorMessage:getType()
    return self.type;
end
-- set 错误类型
function Io.SCInnerErrorMessage:setType(type)
    this.type = type;
    return self;
end

--get 提示内容
function Io.SCInnerErrorMessage:getMessage()
    return self.message;
end
-- set 提示内容
function Io.SCInnerErrorMessage:setMessage(message)
    this.message = message;
    return self;
end

--get 消息id
function Io.SCInnerErrorMessage:getId()
    return self.id;
end
-- set 消息id
function Io.SCInnerErrorMessage:setId(id)
    this.id = id;
    return self;
end

--get ask的value
function Io.SCInnerErrorMessage:getValue()
    return self.value;
end
-- set ask的value
function Io.SCInnerErrorMessage:setValue(value)
    this.value = value;
    return self;
end



ConsumerManager.regMessageDecoder(Io.SCHeartMessage.messageId,
        {
            getEmptyMessage = function()
                return Io.SCHeartMessage:new();
            end
        },"Io.SCHeartMessage");
ConsumerManager.regMessageDecoder(Io.SCInnerErrorMessage.messageId,
        {
            getEmptyMessage = function()
                return Io.SCInnerErrorMessage:new();
            end
        },"Io.SCInnerErrorMessage");
